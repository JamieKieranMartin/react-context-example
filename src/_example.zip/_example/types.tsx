export type Example = {
  id: string;
};
