import { axiosInstance } from '../../core/axios';

export const _post = async (data: any) =>
  await axiosInstance(``, {
    method: 'POST',
    data
  });

export const _put = async (id: string, data: any) =>
  await axiosInstance(`${id}`, {
    method: 'PUT',
    data
  });

export const _delete = async (id: string) =>
  await axiosInstance(`${id}`, {
    method: 'DELETE'
  });
