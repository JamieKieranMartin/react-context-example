import React, { useState } from 'react';
import { Context } from './context';
import { useAPI } from '../../core/utils';
import * as api from './api';

export const Provider = (props: any) => {
  const [refresh, setRefresh] = useState<boolean>(false);

  const { loading, data, error } = useAPI({
    refresh,
    url: ''
  });

  return (
    <Context.Provider
      value={{
        loading,
        data,
        api,
        error,
        refresh: () => setRefresh(!refresh)
      }}
    >
      {props.children}
    </Context.Provider>
  );
};
